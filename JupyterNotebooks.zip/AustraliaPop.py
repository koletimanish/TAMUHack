# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 17:17:51 2020

@author: kolet_x7k8
"""

import pandas as pd
import numpy as np
from geopy.geocoders import Nominatim

geolocator = Nominatim(user_agent='myapplication', timeout = 10)

australia_cities = 'AustraliaPop.xlsx'
df = pd.read_excel(australia_cities)

for i in df['City']:
    location = geolocator.geocode(i)
    print(location.latitude)

print("----------------------------------------------------------------------")

for i in df['City']:
    location = geolocator.geocode(i)
    print(location.longitude)




